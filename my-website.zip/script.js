function sayHi() {
  alert("Thanks for visiting! 🚀");
}